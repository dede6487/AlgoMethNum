function [f] = f2(x)
    f = x*x+x+1;
end